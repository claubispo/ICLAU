const fetch = global.fetch || require('node-fetch');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }
  try {
    const { prompt, name } = req.body || {};
    if (!prompt) {
      res.status(400).json({ error: 'Missing prompt' });
      return;
    }
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      res.status(500).json({ error: 'Missing OPENAI_API_KEY on server' });
      return;
    }

    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Você é a Lumi, assistente gentil, objetiva e acolhedora do app ICLAU. Responda em português do Brasil. Seja clara, breve e útil." },
        { role: "user", content: `${name ? `Meu nome é ${name}. ` : ""}${prompt}` }
      ]
    };

    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      const errText = await r.text();
      res.status(r.status).json({ error: "Upstream error", detail: errText });
      return;
    }

    const data = await r.json();
    const reply = data.choices?.[0]?.message?.content || "Sem resposta no momento.";
    res.status(200).json({ reply });
  } catch (e) {
    res.status(500).json({ error: "Server error", detail: String(e) });
  }
};