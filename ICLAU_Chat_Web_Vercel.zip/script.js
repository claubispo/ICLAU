const $ = (sel) => document.querySelector(sel);
const messagesEl = $("#messages");
const inputEl = $("#input");
const formEl = $("#composer");
const userNameEl = $("#userName");
const settingsDialog = $("#settings");
const btnSettings = $("#btnSettings");
const btnSave = $("#saveSettings");

const state = {
  name: localStorage.getItem("iclau:name") || "Clau",
};

userNameEl.value = state.name;

btnSettings.addEventListener("click", () => settingsDialog.showModal());
btnSave.addEventListener("click", () => {
  state.name = userNameEl.value || "Clau";
  localStorage.setItem("iclau:name", state.name);
});

function addBubble(sender, text){
  const div = document.createElement("div");
  div.className = "bubble " + (sender === "Lumi" ? "ai" : "user");
  div.innerHTML = `<div class="name">${sender}</div><div class="text">${text}</div>`;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function askLumi(prompt){
  addBubble(state.name, prompt);
  inputEl.value = "";
  const thinking = document.createElement("div");
  thinking.className = "bubble ai";
  thinking.innerHTML = `<div class="name">Lumi</div><div class="text">Digitando...</div>`;
  messagesEl.appendChild(thinking);
  messagesEl.scrollTop = messagesEl.scrollHeight;

  try{
    const res = await fetch("/api/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ prompt, name: state.name })
    });
    if(!res.ok){
      throw new Error("Falha na resposta");
    }
    const data = await res.json();
    thinking.querySelector(".text").textContent = data.reply || "(sem resposta)";
  }catch(err){
    thinking.querySelector(".text").textContent = "Ops! Não consegui responder agora. Tente novamente.";
  }
}

formEl.addEventListener("submit",(e)=>{
  e.preventDefault();
  const v = inputEl.value.trim();
  if(!v) return;
  askLumi(v);
});